from casper import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline("[ 🛒Trial SSH ]","trial-ssh"),
Button.inline("[ 🛒Create SSH ]","create-ssh")],
[Button.inline("[ 🛒Delete SSH ]","delete-ssh"),
Button.inline("[ 🛒Check Login SSH ]","login-ssh")],
[Button.inline("[ 🛒Show All User SSH ]","show-ssh")],
[Button.inline("‹ 🔙Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied🤣",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ SSH Account ⟩**
**━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━**
**» OpenSSH:** `443`,`22`
**» SSL/TLS:** `443` **-** `1000`
**» Dropbear:** `443`,`109`,`143`
**» WS SSL:** `443`
**» WS HTTP:** `80`, `8080`
**» WS OVPN SSL:** `443`
**» WS OVPN:** `80`, `8080`
**» BadVPN UDPGW:** `7100` **-** `7300`
**━━━━━━━━━━━━━━━━**
**» Ovpn TCP : http://{DOMAIN}:89/tcp.ovpn
**» Ovpn UDP : http://{DOMAIN}:89/udp.ovpn
**» Ovpn SSL : http://{DOMAIN}:89/ssl.ovpn
**━━━━━━━━━━━━━━━━**
**⟨ Payload WS CDN ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━**
**» 🗓Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━**
"""
			inline = [
[Button.url("[ Grup ]","t.me/CasperGamingChat"),
Button.url("[ Channel ]","t.me/casperinject")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Day •","3"),
Button.inline("• 7 Day •","7")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
──────────────────
    SSH OVPN Premium Account   
──────────────────
Username        :  $Login
Password        :  $Pass
Expired          :  $exp
──────────────────
IP               :  $IP
ISP              :  $ISP 
CITY             :  $CITY
Host             :  $domen
User Limit        :  ${iplim} IP
Port OpenSSH    :  22
Port Dropbear    :  109, 143
Port SSH WS     :  80, 8080
Port SSH SSL WS :  443
Port SSL/TLS     :  8443,8880
Port OVPN WS SSL :  2086
Port OVPN SSL    :  990
Port OVPN TCP    :  $ovpn
Port OVPN UDP    :  $ovpn2
Proxy Squid        :  3128
BadVPN UDP       :  7100, 7300, 7300
───────────────────
SSH UDP VIRAL : $domen:1-65535@$Login:$Pass
───────────────────
Host Slowdns    :  $sldomain
Port Slowdns         :  80, 443, 53 
Pub Key          :   $slkey
───────────────────
Payload WS/WSS   :  HEAD / HTTP/1.1[crlf]Host: bug.mu[crlf][crlf]CF-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf]Upgrade: websocket[crlf][crlf]
───────────────────
OpenVPN SSL      :  http://$domen:89/ssl.ovpn
OpenVPN TCP      :  http://$domen:89/tcp.ovpn
OpenVPN UDP      :  http://$domen:89/udp.ovpn
───────────────────
Save Link Account: http://$domen:89/ssh-$Login.txt
───────────────────
           $author                       
───────────────────
"""
			inline = [
[Button.url("[ Grup ]","t.me/CasperGamingChat"),
Button.url("[ Channel ]","t.me/casperinject")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak😂",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be Deleted:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		try:
			subprocess.check_output(f"userdel -f {user}",shell=True)
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak😂",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		x = subprocess.check_output('bash casper/cek.sh',shell=True).decode("ascii")
		date = DT.date.now()
		text2png(u"%s" % x, 'login.png', fontfullpath = "casper/font.ttf")
		await event.respond(f"""
**Dropbear, OpenSSH, & OpenVPN Login Check**
**Date:** `{date}`
""",file="login.png")
		os.remove("login.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = "awk -F: '($3>=1000)&&($1!='nobody'){print $1}' /etc/passwd"
		x = subprocess.check_output(cmd,shell=True).decode("ascii").split("\n")
		z = []
		for us in x:
			z.append("`"+us+"`")
		zx = "\n".join(z)
		await event.respond(f"""
**✨Showing All SSH User✨**

{zx}
`
**🪐Total SSH Account🪐:** `{str(len(z))}`
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
