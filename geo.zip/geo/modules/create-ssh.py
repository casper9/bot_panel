from geo import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Day •","3"),
Button.inline("• 7 Day •","7")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
──────────────────
    SSH OVPN Premium Account   
──────────────────
Username        :  $Login
Password        :  $Pass
Expired          :  $exp
──────────────────
IP               :  $IP
ISP              :  $ISP 
CITY             :  $CITY
Host             :  $domen
User Limit        :  ${iplim} IP
Port OpenSSH    :  22
Port Dropbear    :  109, 143
Port SSH WS     :  80, 8080
Port SSH SSL WS :  443
Port SSL/TLS     :  8443,8880
Port OVPN WS SSL :  2086
Port OVPN SSL    :  990
Port OVPN TCP    :  $ovpn
Port OVPN UDP    :  $ovpn2
Proxy Squid        :  3128
BadVPN UDP       :  7100, 7300, 7300
───────────────────
SSH UDP VIRAL : $domen:1-65535@$Login:$Pass
───────────────────
Host Slowdns    :  $sldomain
Port Slowdns         :  80, 443, 53 
Pub Key          :   $slkey
───────────────────
Payload WS/WSS   :  HEAD / HTTP/1.1[crlf]Host: bug.mu[crlf][crlf]CF-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: keep-alive[crlf]Upgrade: websocket[crlf][crlf]
───────────────────
OpenVPN SSL      :  http://$domen:89/ssl.ovpn
OpenVPN TCP      :  http://$domen:89/tcp.ovpn
OpenVPN UDP      :  http://$domen:89/udp.ovpn
───────────────────
Save Link Account: http://$domen:89/ssh-$Login.txt
───────────────────
           $author                       
───────────────────
"""
			inline = [
[Button.url("[ Grup ]","t.me/CasperGamingChat"),
Button.url("[ Channel ]","t.me/casperinject")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak😂",alert=True)
